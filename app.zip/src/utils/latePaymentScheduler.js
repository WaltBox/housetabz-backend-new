// src/utils/latePaymentScheduler.js
const cron = require('node-cron');
const { processLateCharges } = require('../workers/latePaymentWorker');

let latePaymentJob = null;

/**
 * Start the late payment processing scheduler
 * Runs every day at 2 AM to check for late charges and update HSI
 */
function startLatePaymentScheduler() {
  if (latePaymentJob) {
    console.log('Late payment scheduler is already running');
    return;
  }

  // Run daily at 2 AM - '0 2 * * *'
  // For testing every 2 hours: '0 */2 * * *'
  // For testing every 5 minutes: '*/5 * * * *'
  latePaymentJob = cron.schedule('0 2 * * *', async () => {
    console.log('🔄 Starting scheduled late payment processing...');
    try {
      const result = await processLateCharges();
      console.log('✅ Late payment processing completed:', result);
    } catch (error) {
      console.error('❌ Late payment processing failed:', error);
    }
  }, {
    scheduled: true,
    timezone: "America/New_York" // Adjust to your timezone
  });

  console.log('⏰ Late payment scheduler started - runs daily at 2 AM');
}

/**
 * Stop the late payment scheduler
 */
function stopLatePaymentScheduler() {
  if (latePaymentJob) {
    latePaymentJob.destroy();
    latePaymentJob = null;
    console.log('Late payment scheduler stopped');
  }
}

/**
 * Manually trigger late payment processing (for testing)
 */
async function triggerLatePaymentProcessing() {
  console.log('🧪 Manually triggering late payment processing...');
  try {
    const result = await processLateCharges();
    console.log('✅ Manual late payment processing completed:', result);
    return result;
  } catch (error) {
    console.error('❌ Manual late payment processing failed:', error);
    throw error;
  }
}

module.exports = {
  startLatePaymentScheduler,
  stopLatePaymentScheduler,
  triggerLatePaymentProcessing
};