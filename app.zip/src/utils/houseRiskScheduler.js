// src/utils/houseRiskScheduler.js
const cron = require('node-cron');
const { House } = require('../models');
const houseRiskService = require('../services/houseRiskService');

let houseRiskJob = null;

/**
 * Start the house risk assessment scheduler
 * Runs every Friday at 3 AM to perform comprehensive risk assessment and HSI updates
 */
function startHouseRiskScheduler() {
  if (houseRiskJob) {
    console.log('House risk scheduler is already running');
    return;
  }

  // Run every Friday at 3 AM - '0 3 * * 5'
  // For testing every 10 minutes: '*/10 * * * *'
  // For testing daily at 3 AM: '0 3 * * *'
  houseRiskJob = cron.schedule('0 3 * * 5', async () => {
    console.log('🔄 Starting weekly house risk assessment...');
    try {
      const result = await performWeeklyRiskAssessment();
      console.log('✅ Weekly house risk assessment completed:', result);
    } catch (error) {
      console.error('❌ Weekly house risk assessment failed:', error);
    }
  }, {
    scheduled: true,
    timezone: "America/New_York" // Adjust to your timezone
  });

  console.log('⏰ House risk scheduler started - runs every Friday at 3 AM');
}

/**
 * Stop the house risk scheduler
 */
function stopHouseRiskScheduler() {
  if (houseRiskJob) {
    houseRiskJob.destroy();
    houseRiskJob = null;
    console.log('House risk scheduler stopped');
  }
}

/**
 * Perform comprehensive risk assessment for all houses
 */
async function performWeeklyRiskAssessment() {
  try {
    // Get all houses
    const houses = await House.findAll({
      attributes: ['id', 'name'],
      order: [['id', 'ASC']]
    });

    console.log(`🏘️  Performing risk assessment for ${houses.length} houses...`);

    const results = [];
    let successCount = 0;
    let failureCount = 0;
    let totalRiskAdjustments = 0;

    // Process each house
    for (const house of houses) {
      try {
        console.log(`🏠 Assessing risk for house ${house.id} (${house.name})...`);
        
        const hsiResult = await houseRiskService.updateHouseHSI(house.id);
        
        if (hsiResult) {
          const riskImpact = Math.abs(1.0 - hsiResult.riskMultiplier);
          if (riskImpact > 0.02) totalRiskAdjustments++; // Count significant adjustments
          
          results.push({
            houseId: house.id,
            houseName: house.name,
            hsiScore: hsiResult.score,
            bracket: hsiResult.bracket,
            feeMultiplier: hsiResult.feeMultiplier,
            riskMultiplier: hsiResult.riskMultiplier,
            unpaidChargesCount: hsiResult.unpaidChargesCount,
            unpaidAmount: hsiResult.unpaidAmount,
            riskLevel: getRiskLevel(hsiResult.currentRiskFactor),
            success: true
          });
          successCount++;
          
          console.log(`✅ House ${house.id}: HSI=${hsiResult.score}, Risk=${(hsiResult.currentRiskFactor * 100).toFixed(1)}%, Fee=${hsiResult.feeMultiplier.toFixed(3)}x`);
        } else {
          results.push({
            houseId: house.id,
            houseName: house.name,
            success: false,
            error: 'No users found or HSI calculation returned null'
          });
          failureCount++;
          console.log(`⚠️  House ${house.id}: No risk assessment (no users)`);
        }
      } catch (error) {
        console.error(`❌ Error assessing risk for house ${house.id}:`, error);
        results.push({
          houseId: house.id,
          houseName: house.name,
          success: false,
          error: error.message
        });
        failureCount++;
      }

      // Small delay to avoid overwhelming the database
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Calculate summary statistics
    const successfulResults = results.filter(r => r.success);
    const avgHSI = successfulResults.length > 0 
      ? Math.round(successfulResults.reduce((sum, r) => sum + r.hsiScore, 0) / successfulResults.length)
      : 50;
    
    const highRiskHouses = successfulResults.filter(r => r.hsiScore < 40).length;
    const excellentHouses = successfulResults.filter(r => r.hsiScore >= 80).length;

    const summary = {
      totalHouses: houses.length,
      successCount,
      failureCount,
      averageHSI: avgHSI,
      highRiskHouses,
      excellentHouses,
      housesWithRiskAdjustments: totalRiskAdjustments,
      timestamp: new Date().toISOString(),
      results
    };

    console.log(`📊 WEEKLY RISK ASSESSMENT SUMMARY:`);
    console.log(`   🏘️  Houses processed: ${houses.length} (${successCount} success, ${failureCount} failures)`);
    console.log(`   📈 Average HSI: ${avgHSI}`);
    console.log(`   🚨 High risk houses (HSI < 40): ${highRiskHouses}`);
    console.log(`   ⭐ Excellent houses (HSI ≥ 80): ${excellentHouses}`);
    console.log(`   ⚖️  Houses with risk adjustments: ${totalRiskAdjustments}`);

    return summary;

  } catch (error) {
    console.error('Error in performWeeklyRiskAssessment:', error);
    throw error;
  }
}

/**
 * Get human-readable risk level
 */
function getRiskLevel(riskFactor) {
  if (riskFactor <= 0.03) return 'EXCELLENT';
  if (riskFactor <= 0.08) return 'GOOD';
  if (riskFactor <= 0.15) return 'FAIR';
  if (riskFactor <= 0.25) return 'CONCERNING';
  if (riskFactor <= 0.40) return 'HIGH_RISK';
  return 'CRITICAL';
}

/**
 * Manually trigger house risk assessment for all houses (for testing)
 */
async function triggerRiskAssessment() {
  console.log('🧪 Manually triggering house risk assessment for all houses...');
  try {
    const result = await performWeeklyRiskAssessment();
    console.log('✅ Manual house risk assessment completed:', result);
    return result;
  } catch (error) {
    console.error('❌ Manual house risk assessment failed:', error);
    throw error;
  }
}

/**
 * Trigger risk assessment for a specific house (for testing)
 */
async function triggerHouseRiskAssessment(houseId) {
  console.log(`🧪 Manually triggering risk assessment for house ${houseId}...`);
  try {
    const result = await houseRiskService.updateHouseHSI(houseId);
    console.log(`✅ Manual risk assessment completed for house ${houseId}:`, result);
    return result;
  } catch (error) {
    console.error(`❌ Manual risk assessment failed for house ${houseId}:`, error);
    throw error;
  }
}

/**
 * Cleanup old risk history records (run monthly)
 */
async function performMonthlyCleanup() {
  console.log('🧹 Starting monthly risk history cleanup...');
  try {
    const deletedCount = await houseRiskService.cleanupOldRiskHistory();
    console.log(`✅ Monthly cleanup completed: ${deletedCount} records deleted`);
    return deletedCount;
  } catch (error) {
    console.error('❌ Monthly cleanup failed:', error);
    throw error;
  }
}

module.exports = {
  startHouseRiskScheduler,
  stopHouseRiskScheduler,
  performWeeklyRiskAssessment,
  triggerRiskAssessment,
  triggerHouseRiskAssessment,
  performMonthlyCleanup
};