// middleware/auth/adminAuth.js
const jwt = require('jsonwebtoken');
const { Admin } = require('../../models');

const JWT_SECRET = process.env.JWT_SECRET;

const authenticateAdmin = async (req, res, next) => {
  console.log('🔍 ADMIN AUTH MIDDLEWARE');
  console.log('🔍 Path:', req.path);
  console.log('🔍 Method:', req.method);
  console.log('🔍 Auth header:', req.headers.authorization ? 'Present' : 'Missing');
  
  try {
    // Check for Authorization header
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      console.log('❌ No Bearer token found');
      return res.status(401).json({
        error: 'Authentication required',
        message: 'Valid authentication token required'
      });
    }

    // Extract token
    const token = authHeader.split(' ')[1];
    console.log('🔍 Token received:', token.substring(0, 20) + '...');

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log('🔍 Token decoded successfully:', {
      id: decoded.id,
      email: decoded.email,
      type: decoded.type,
      role: decoded.role
    });

    // Check if token type is admin (but don't require it)
    if (decoded.type && decoded.type !== 'admin') {
      console.log('❌ Wrong token type. Expected: admin, Got:', decoded.type);
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin token required'
      });
    }

    // Find admin and verify they exist and are active
    const admin = await Admin.findByPk(decoded.id);
    console.log('🔍 Admin lookup result:', admin ? {
      id: admin.id,
      email: admin.email,
      isActive: admin.isActive,
      role: admin.role
    } : 'Not found');

    if (!admin) {
      console.log('❌ Admin not found in database');
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Admin not found'
      });
    }

    if (!admin.isActive) {
      console.log('❌ Admin account is inactive');
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Admin account inactive'
      });
    }

    // Add admin to request object (following partner pattern)
    req.current_admin = admin;
    req.isAdminRequest = true;
    console.log('✅ Admin authentication successful for:', admin.email);
    next();

  } catch (error) {
    console.log('❌ Admin auth error:', error.name, error.message);
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Token expired'
      });
    }

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid token'
      });
    }

    console.error('Unexpected admin authentication error:', error);
    res.status(500).json({
      error: 'Server error',
      message: 'An unexpected error occurred'
    });
  }
};

module.exports = { authenticateAdmin };