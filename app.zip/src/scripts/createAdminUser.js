// scripts/createWaltAdmin.js
require('dotenv').config();
const { Admin, sequelize } = require('../models');

const createWaltAdmin = async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connected successfully');

    const adminData = {
      email: 'walt@housetabz.com',
      password: 'waltiscool', // Will be hashed by Admin model
      firstName: 'Walt',
      lastName: 'Boxwell',
      role: 'super_admin'
    };

    // Check if Walt already exists
    const existingAdmin = await Admin.findOne({ where: { email: adminData.email } });
    
    if (existingAdmin) {
      console.log('Walt already exists as admin!');
      console.log('Admin details:', {
        id: existingAdmin.id,
        email: existingAdmin.email,
        role: existingAdmin.role,
        isActive: existingAdmin.isActive
      });
    } else {
      console.log('Creating Walt as HouseTabz admin...');
      
      const adminUser = await Admin.create(adminData);

      console.log('✅ Walt created as admin successfully!');
      console.log('Admin details:', {
        id: adminUser.id,
        email: adminUser.email,
        firstName: adminUser.firstName,
        lastName: adminUser.lastName,
        role: adminUser.role,
        isActive: adminUser.isActive
      });
    }

    console.log('\n🔑 Admin Login Credentials:');
    console.log('Email: walt@housetabz.com');
    console.log('Password: waltiscool');
    console.log('Role: super_admin');
    console.log('\n🧪 Test login with:');
    console.log('curl -X POST http://localhost:3004/api/admin/login \\');
    console.log('  -H "Content-Type: application/json" \\');
    console.log('  -d \'{"email":"walt@housetabz.com","password":"waltiscool"}\'');

  } catch (error) {
    console.error('Error creating Walt admin:', error);
    
    // Handle specific errors
    if (error.name === 'SequelizeValidationError') {
      console.log('Validation errors:');
      error.errors.forEach(err => {
        console.log(`- ${err.path}: ${err.message}`);
      });
    }
  } finally {
    await sequelize.close();
    console.log('\nDatabase connection closed');
  }
};

// Run the script
console.log('Creating Walt as HouseTabz admin...\n');
createWaltAdmin();