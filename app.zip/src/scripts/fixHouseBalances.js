// scripts/fixHouseBalances.js
const { sequelize, HouseFinance, Transaction } = require('../models');

async function fixHouseBalances() {
  try {
    console.log('Starting house balance fix...');
    
    // Connect to database
    await sequelize.authenticate();
    console.log('Database connected successfully');
    
    // Show current wrong balances
    console.log('\n=== CURRENT WRONG BALANCES ===');
    const currentBalances = await HouseFinance.findAll({
      where: { houseId: [4, 5] },
      order: [['houseId', 'ASC']]
    });
    
    currentBalances.forEach(hf => {
      console.log(`House ${hf.houseId}: Balance = ${hf.balance}, Ledger = ${hf.ledger}`);
    });
    
    // Fix House 4: Should be 473.67
    console.log('\n=== FIXING HOUSE 4 ===');
    const house4 = await HouseFinance.findOne({ where: { houseId: 4 } });
    if (house4) {
      console.log(`House 4 - Before: ${house4.balance}`);
      const balanceBefore = parseFloat(house4.balance);
      const correctBalance = 473.67;
      const adjustmentAmount = correctBalance - balanceBefore; // This will be positive (adding back)
      
      house4.balance = correctBalance;
      house4.lastTransactionDate = new Date();
      await house4.save();
      
      // Create adjustment transaction record
      await Transaction.create({
        houseId: 4,
        type: 'ADJUSTMENT',
        amount: adjustmentAmount,
        description: 'Balance correction due to double-debiting bug fix',
        balanceBefore: balanceBefore,
        balanceAfter: correctBalance,
        status: 'COMPLETED',
        metadata: {
          reason: 'double_debit_correction',
          fixDate: new Date().toISOString(),
          notes: 'Correcting balance that was wrong due to duplicate payment processing'
        }
      });
      
      console.log(`House 4 - After: ${house4.balance} (Adjustment: +${adjustmentAmount})`);
    } else {
      console.log('House 4 finance record not found!');
    }
    
    // Fix House 5: Should be 574.94
    console.log('\n=== FIXING HOUSE 5 ===');
    const house5 = await HouseFinance.findOne({ where: { houseId: 5 } });
    if (house5) {
      console.log(`House 5 - Before: ${house5.balance}`);
      const balanceBefore = parseFloat(house5.balance);
      const correctBalance = 574.94;
      const adjustmentAmount = correctBalance - balanceBefore; // This will be positive (adding back)
      
      house5.balance = correctBalance;
      house5.lastTransactionDate = new Date();
      await house5.save();
      
      // Create adjustment transaction record
      await Transaction.create({
        houseId: 5,
        type: 'ADJUSTMENT',
        amount: adjustmentAmount,
        description: 'Balance correction due to double-debiting bug fix',
        balanceBefore: balanceBefore,
        balanceAfter: correctBalance,
        status: 'COMPLETED',
        metadata: {
          reason: 'double_debit_correction',
          fixDate: new Date().toISOString(),
          notes: 'Correcting balance that was wrong due to duplicate payment processing'
        }
      });
      
      console.log(`House 5 - After: ${house5.balance} (Adjustment: +${adjustmentAmount})`);
    } else {
      console.log('House 5 finance record not found!');
    }
    
    // Verify the fixes
    console.log('\n=== CORRECTED BALANCES ===');
    const correctedBalances = await HouseFinance.findAll({
      where: { houseId: [4, 5] },
      order: [['houseId', 'ASC']]
    });
    
    correctedBalances.forEach(hf => {
      console.log(`House ${hf.houseId}: Balance = ${hf.balance}, Ledger = ${hf.ledger}`);
    });
    
    // Show all house balances for reference
    console.log('\n=== ALL HOUSE BALANCES ===');
    const allBalances = await HouseFinance.findAll({
      order: [['houseId', 'ASC']]
    });
    
    allBalances.forEach(hf => {
      console.log(`House ${hf.houseId}: Balance = ${hf.balance}, Ledger = ${hf.ledger}`);
    });
    
    console.log('\n✅ House balance fix completed successfully!');
    console.log('\n=== ADJUSTMENT TRANSACTIONS CREATED ===');
    const adjustmentTransactions = await Transaction.findAll({
      where: { 
        type: 'ADJUSTMENT',
        houseId: [4, 5]
      },
      order: [['createdAt', 'DESC']],
      limit: 2
    });
    
    adjustmentTransactions.forEach(txn => {
      console.log(`House ${txn.houseId}: ${txn.description} - Amount: ${txn.amount}`);
    });
    
  } catch (error) {
    console.error('❌ Error fixing house balances:', error);
  } finally {
    await sequelize.close();
    console.log('Database connection closed');
    process.exit(0);
  }
}

// Run the fix
fixHouseBalances();