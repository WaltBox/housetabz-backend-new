// src/services/s3Service.js
const { S3Client, PutObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { fromEnv } = require("@aws-sdk/credential-providers");
require('dotenv').config();

class S3Service {
  constructor() {

    
    this.client = new S3Client({
      region: process.env.AWS_REGION,
      credentials: fromEnv(),
      maxAttempts: 3
    });
    
    this.bucket = process.env.AWS_S3_BUCKET;
  }

  async uploadFile(file, folder = 'partner-images') {
    if (!file) throw new Error('No file provided');

    const fileExtension = file.originalname.split('.').pop();
    const fileName = `${folder}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExtension}`;

    const params = {
      Bucket: this.bucket,
      Key: fileName,
      Body: file.buffer,
      ContentType: file.mimetype
      // Removed ACL setting since bucket doesn't allow it
    };

    try {
  

      const command = new PutObjectCommand(params);
      const result = await this.client.send(command);
      
      // Construct the URL
      const url = `https://${this.bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileName}`;
     
      
      return {
        url,
        key: fileName,
        etag: result.ETag
      };
    } catch (error) {
      console.error('Detailed S3 upload error:', {
        message: error.message,
        code: error.code,
        requestId: error.$metadata?.requestId,
        statusCode: error.$metadata?.httpStatusCode
      });
      throw new Error(`Failed to upload file to S3: ${error.message}`);
    }
  }

  async deleteFile(key) {
    if (!key) return;

    const params = {
      Bucket: this.bucket,
      Key: key
    };

    try {
     
      const command = new DeleteObjectCommand(params);
      await this.client.send(command);

    } catch (error) {
      console.error('S3 delete error:', error);
      // Don't throw on delete errors, just log them
      console.warn(`Failed to delete file from S3: ${key}`);
    }
  }
}

module.exports = new S3Service();